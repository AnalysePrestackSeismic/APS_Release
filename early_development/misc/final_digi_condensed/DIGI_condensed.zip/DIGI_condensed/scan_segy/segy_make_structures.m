function segy_make_structures(filepath,filename_string,il_byte,xl_byte,output_dir)
% -------------------------------------------------------------------------
% SEGY_MAKE_STRUCTURE: function to scan SEGY file to gain geometry and
% sample information used by other functions.
%   Inputs:
%       filepath = path of directory containing input angle stacks only.
%       filename = name of SEGY file to scan.
%       il_byte  = inline number byte location
%       xl_byte  = crossline number byte location
%       output_dir = directory in which all DIGI outputs should be saved.
%   Outputs:
%       .mat file = metadata including sample rate, n_samples etc.
%       .mat_lite file = binary file containing IL/XL byte locations.
% -------------------------------------------------------------------------

% Check for *
multifile = strfind(filename_string,'*');

if multifile
    [files_in nfiles] = directory_scan(filepath);
else
    nfiles = 1;
end

start_point = pwd; % remember starting directory

for i_file = 1:1:nfiles

    if nfiles > 1
        filename = files_in.names{i_file};
        filepath = files_in.path{i_file};
    end
    
    % Can make this run in parallel now
    segy_make_structure(filepath,filename,il_byte,xl_byte);

end

% Save meta information about files scanned to .mat file

    
cd( start_point)
end