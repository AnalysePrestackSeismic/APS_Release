function [] = wavelet_avg(job_meta_path)
% -------------------------------------------------------------------------
% WAVELET_AVG: function to create wavelet set for use in DIGI. Currently
% wavelets vary with time and angle. Spatially variant wavelets not yet
% implimented.
%   Inputs:
%       seismic_mat_path = path to .mat file created using
%       segy_make_structure function.
%       n_blocks = number of blocks to divide processing into.
%   Outputs:
%       all_wavelets_time.mat = mat file to be input into DIGI.
% -------------------------------------------------------------------------

% Load job meta information 
job_meta = load(job_meta_path);

for i_vol = 1:1:job_meta.nvols
    for i_block = 1:1:job_meta.n_blocks 
        fid_wav = fopen(strcat(job_meta.wav_directory,job_meta.volumes{i_vol}, ...
            '_fft_wavelets_block_',num2str(i_block),'.bin'));
        w = fread(fid_wav,'float32');
        fclose(fid_wav);
        w = reshape(w,[],job_meta.n_win);
        if i_block == 1
            tmp_w = w;
        else
            tmp_w(2:end,:) = tmp_w(2:end,:)+w(2:end,:);
            if sum(logical(w(1,:))) > sum(logical(tmp_w(1,:)))
                tmp_w(1,:) = w(1,:);
            end
        end
    end
        
    % Average wavelets across blocks
    avg_w = [tmp_w(1,:); bsxfun(@rdivide,tmp_w(3:end,:),tmp_w(2,:))];
    avg_w = avg_w(:,logical(1-logical(sum(isnan(avg_w)))));

    avg_w = avg_w(:,logical(sum(avg_w(2:end,:))));
    avg_w_time = [avg_w(1,:); circshift(ifft(avg_w(2:end,:),'symmetric'),floor(job_meta.ns_win/2))];

    % Save average wavelets
    save(strcat(job_meta.wav_directory,job_meta.volumes{i_vol},'_avg_w_freq.mat'),'avg_w','-v7.3');
    save(strcat(job_meta.wav_directory,job_meta.volumes{i_vol},'_avg_w_freq.mat'),'avg_w_time','-v7.3');

    % Compile final wavelets into cell array to be used in IG inversion
    all_wavelets_freq{1,i_vol} = avg_w;
    all_wavelets_time{1,i_vol} = avg_w_time;

    % Save final wavelet files
    wavelet_length(i_vol) = size(avg_w_time,2);
end

    figure
    subplot(1,2,2); imagesc(cell2mat(all_wavelets_time)');
    % Each angle stack has different data coverage i.e. near stack does
    % not go deep/far stack has no shallow information. Crop wavelet
    % array to interval of full data coverage
    crop = min(wavelet_length);
    
    % Form wavelets into 3D array
    for ii = 1:job_meta.n_win
        win_ind(ii) = floor(job_meta.ns_win/2)+(ii-1)*job_meta.ns_overlap;
    end
    wavelets_3D_time = NaN(job_meta.n_win,job_meta.ns_win,job_meta.nvols);
    for i_vol = 1:1:job_meta.nvols
        [~,Locb] = ismember(all_wavelets_time{1,i_vol}(1,:),win_ind);
        wavelets_3D_time(Locb,:,i_vol) = all_wavelets_time{1,i_vol}(2:end,:)';
        
    end
        
    for i_vol = 1:1:job_meta.nvols
        wavelet_z_grid{i_vol} = all_wavelets_time{i_vol}(2:end,:);
    end
    wavelet_z_grid = cell2mat(wavelet_z_grid);
    
    
    for i_vol = 1:1:job_meta.nvols
        all_wavelets_time{1,i_vol} = all_wavelets_time{1,i_vol}(:,1:crop);
    end
        
    save(strcat(job_meta.wav_directory,'all_wavelets_freq.mat'),'all_wavelets_freq','-v7.3');
    save(strcat(job_meta.wav_directory,'all_wavelets_time.mat'),'all_wavelets_time','-v7.3');
                
    % Plot wavelets
    figure
    for a = 1:size(all_wavelets_time,2)
        subplot(size(all_wavelets_time,2),1,a);
        imagesc(bsxfun(@rdivide,all_wavelets_time{1,a}(2:end,:),max(all_wavelets_time{1,a}(2:end,:))));
        xlabel('Wavelet number (Increasing Z >>)');
        ylabel('Time (ms)');
        set(gca,'ytick',[])
    end
end