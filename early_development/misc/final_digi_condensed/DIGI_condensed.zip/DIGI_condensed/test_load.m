i_vol='2';

for i_block = 1:1:500
    
    wavelet_estimation('/bgdata/segy/job_meta/job_meta_02Nov2013.mat',num2str(i_block));
    
%     i_block = num2str(i_block);
% 
%     [seismic, traces, ilxl_read] = node_segy_read('/bgdata/segy/job_meta/job_meta_01Nov2013.mat',i_vol,i_block);
%     [wb_idx] = water_bottom_flatten_lite(traces);
%     [traces_flat] = trace_flatten(traces,wb_idx);
%     results_out{1,1} = 'ilxl numbers';
%     results_out{1,2}{1,1} = ilxl_read;
%     results_out{2,1} = strcat('flat_vol_',i_vol);
%     results_out{2,2} = traces_flat;
% 
%     i_block = str2num(i_block);
%     node_segy_write_traces(results_out,i_block,'/bgdata/segy/output_segy/');
end