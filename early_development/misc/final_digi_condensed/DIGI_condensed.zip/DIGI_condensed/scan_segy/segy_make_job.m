function segy_make_job(filepath,filename_string,il_byte,xl_byte,...
    offset_byte,parallel,output_dir,pkey_blocks,skey_blocks,tkey_blocks)
% -------------------------------------------------------------------------
% SEGY_MAKE_STRUCTURE: function to scan SEGY file to gain geometry and
% sample information used by other functions.
%   Inputs:
%       filepath = path of directory containing input angle stacks only as
%       cell array.
%       filename = name of SEGY file to scan.
%       il_byte  = inline number byte location
%       xl_byte  = crossline number byte location
%       output_dir = directory in which all DIGI outputs should be saved.
%   Outputs:
%       .mat file = metadata including sample rate, n_samples etc.
%       .mat_lite file = binary file containing IL/XL byte locations.
% -------------------------------------------------------------------------
pkey_loc = 1; % column numbers needs to be implemented
skey_loc = 2;
byte_loc = 3;
skey_max_loc = 4;
skey_inc_loc = 5;
tkey_loc = 6;
tkey_max_loc = 7;
tkey_inc_loc = 8;

il_byte = str2num(il_byte);
xl_byte = str2num(xl_byte);
offset_byte = str2num(offset_byte);
parallel = str2num(parallel);

[files_in,nfiles] = directory_scan(filepath,filename_string);
files_in.names = sort_nat(files_in.names);
start_point = pwd; % remember starting directory

for i_file = 1:1:nfiles

    filename = files_in.names{i_file};
    filepath = files_in.path{i_file};
   
    % Can make this run in parallel now
    if parallel == 1
        %slurm submit
    else
        segy_make_structure(filepath,filename,il_byte,xl_byte);
    end  
    
end
%job_meta.non_live_traces = non_live_traces;
% Save meta information about files scanned to .mat file
job_meta.files = regexprep(files_in.names', 'segy', 'mat_lite');
%job_meta.files = cell2mat(job_meta.files);
job_meta.files = unique(job_meta.files);
job_meta.paths = unique(files_in.path');
job_meta.output_dir = output_dir;
job_meta.il_byte = il_byte;
job_meta.xl_byte = xl_byte;
job_meta.offset_byte = offset_byte;

vol_names = strfind(files_in.names', '_block');

for i_file = 1:1:nfiles
    job_meta.volumes{i_file} = files_in.names{i_file}(1:vol_names{i_file}-1); 
end
job_meta.volumes = unique(job_meta.volumes)';
job_meta.nvols = size(job_meta.volumes,1);
for i_vol = 1:1:job_meta.nvols
    job_meta.angle{i_vol,1} = str2double(regexp(job_meta.volumes{i_vol},'(\d{2})','match'));
    
    % find files associated with volume from all blocks
    [files_in,nfiles] = directory_scan(job_meta.paths,job_meta.volumes{i_vol});
    job_meta.vol_traces{i_vol,1} = 0;
    ii = 1;
    for il = 1:nfiles
        if strfind(files_in.names{il},'.mat_lite')
            seismic = segy_read_binary(strcat(files_in.path{il},files_in.names{il}));
            job_meta.vol_traces{i_vol,1} = job_meta.vol_traces{i_vol,1}+seismic.n_traces;
            pkey_min(ii) = min(seismic.trace_ilxl_bytes(:,pkey_loc));
            pkey_max(ii) = max(seismic.trace_ilxl_bytes(:,pkey_loc));
            pkey_inc(ii) = mode(diff(unique(seismic.trace_ilxl_bytes(:,pkey_loc))));
            skey_min(ii) = min(seismic.trace_ilxl_bytes(:,skey_loc));
            skey_max(ii) = max(seismic.trace_ilxl_bytes(:,skey_max_loc));
            skey_inc(ii) = mode(seismic.trace_ilxl_bytes(:,skey_inc_loc));          
            
            if seismic.is_gather == 1
                tkey_min(ii) = min(seismic.trace_ilxl_bytes(:,tkey_loc));
                tkey_max(ii) = max(seismic.trace_ilxl_bytes(:,tkey_max_loc));
                tkey_inc(ii) = mode(seismic.trace_ilxl_bytes(:,tkey_inc_loc));
            end
            ii = ii + 1;
        end
    end  
    job_meta.vol_nblocks(i_vol,1) = ii-1;
    job_meta.pkey_min(i_vol,1) = min(pkey_min);
    job_meta.pkey_max(i_vol,1) = max(pkey_max);
    job_meta.pkey_inc(i_vol,1) = mode(pkey_inc);
    job_meta.skey_min(i_vol,1) = min(skey_min);
    job_meta.skey_max(i_vol,1) = max(skey_max);
    job_meta.skey_inc(i_vol,1) = mode(skey_inc);
    if seismic.is_gather == 1
        job_meta.tkey_min(i_vol,1) = min(tkey_min);
        job_meta.tkey_max(i_vol,1) = max(tkey_max);
        job_meta.tkey_inc(i_vol,1) = mode(tkey_inc);
        job_meta.is_gather = 1;
    else
        job_meta.is_gather = 0;
    end
end
%job_meta.files = reshape(job_meta.files,[],job_meta.nvols);
job_meta.s_rate = seismic.s_rate;
job_meta.vol_traces = cell2mat(job_meta.vol_traces);
% store mean angle?
% separate blocks for a single volume
%job_meta.volumes = cell2mat(job_meta.volumes);
str_date = date;
str_date = regexprep(str_date, '-', '');
job_meta_dir = strcat(job_meta.output_dir,'job_meta/');
mkdir(job_meta_dir);
job_meta_path = strcat(job_meta_dir,'job_meta_',str_date,'.mat');

save(job_meta_path,'-struct','job_meta','-v7.3'); % Saves Seismic structure to mat file
job_meta = load(job_meta_path);
[job_meta.block_keys,job_meta.n_blocks] = segy_make_blocks(job_meta_path,pkey_blocks,skey_blocks,tkey_blocks);

save(job_meta_path,'-struct','job_meta','-v7.3'); % Saves Seismic structure to mat file

fprintf('Saved seismic structure to file ...\n')
    
cd(start_point)
end