function [seismic] = segy_make_structure(filepath,filename,il_byte,xl_byte,output_dir,varargin)
% -------------------------------------------------------------------------
% SEGY_MAKE_STRUCTURE: function to scan SEGY file to gain geometry and
% sample information used by other functions.
%   Inputs:
%       filepath = path of directory containing input angle stacks only.
%       filename = name of SEGY file to scan.
%       il_byte  = inline number byte location
%       xl_byte  = crossline number byte location
%       output_dir = directory in which all DIGI outputs should be saved.
%   Outputs:
%       .mat file = metadata including sample rate, n_samples etc.
%       .mat_lite file = binary file containing IL/XL byte locations.
% -------------------------------------------------------------------------

% Check for *
multifile = strfind(filename,'*');

if multifile
    [files_in nfiles] = directory_scan(filepath);
else
    nfiles = 1;
end

start_point = pwd; % remember starting directory
for i_file = 1:1:nfiles
    if nfiles > 1
        filename = files_in.names{i_file};
        filepath = files_in.path{i_file};
    end
    seismic.filepath = strcat(filepath,filename);
    seismic.input_dir = filepath;
    seismic.scanned_file = filename;
    seismic.output_dir = output_dir;
    
    % Check for existing scan
    if exist(strcat(seismic.output_dir,'segy_structure'),'dir') == 0
        mkdir(strcat(seismic.output_dir,'segy_structure'));
        cd(strcat(seismic.output_dir,'segy_structure'));
    else
        cd(strcat(seismic.output_dir,'segy_structure'));
    end
    
    file_mat = regexp(filename,'\.','split');
    file_mat = strcat(seismic.output_dir,'segy_structure/',file_mat{1},'.mat');
    scan_exist = exist(file_mat,'file');
    
    cd(start_point)
    
    if scan_exist == 0
        % Scan segy as previous scan has not been made
        % Read input file
        seismic.fid=fopen(strcat(filepath,filename),'r','b');
        
        fprintf('Scan does not exist\n');
        fprintf('Scanning file: %s ...\n',filename);
        
        % Read textual header (3200 bytes)
        seismic.text_header = fread(seismic.fid,3200,'uchar');
        seismic.text_header = char(ebcdic2ascii(reshape(seismic.text_header,80,40)'));
        
        % Read binary header as
        seismic.binary_header=fread(seismic.fid,400,'uint8');
        
        % Re-interpret binary header as uint16 or uint32 as required
        two_bytes=seismic.binary_header(1:2:399)*256+seismic.binary_header(2:2:400);
        four_bytes=((seismic.binary_header(1:4:9)*256+seismic.binary_header(2:4:10))*256+seismic.binary_header(3:4:11))*256+seismic.binary_header(4:4:12);
        seismic.binary_header=[four_bytes(1:3);two_bytes(7:200)];
        
        seismic.n_samples = seismic.binary_header(8);
        seismic.s_rate = seismic.binary_header(6);
        seismic.ilxl_bytes = [il_byte xl_byte];
        seismic.file_type = seismic.binary_header(10);
        if seismic.file_type < 1 || seismic.file_type > 5
            seismic.file_type = input('No standard seismic file type. Please enter seismic file type (1 (IBM),2,3,4 or 5 (IEEE)): ', 's');
            seismic.file_type = str2num(seismic.file_type);
        end
        % Calculate number of traces
        ll = dir(seismic.filepath);
        seismic.n_traces = 0.25*(ll.bytes-3600)/(seismic.n_samples+60);
        
        % Set number of traces per block
        blocktr = 10000;
        loop_end = floor(seismic.n_traces/blocktr);
        
        filepath_binary = uint64(seismic.filepath);
        pad_filepath = zeros(1,(2000-length(filepath_binary)));
        filepath_binary = [filepath_binary,pad_filepath];
        fid_write = fopen(strcat(file_mat),'a');
        fwrite(fid_write,[filepath_binary';seismic.file_type;seismic.n_samples],'double');
        skip_textual_binary = 3600;
        trc_head = 240;
        trc_length = seismic.n_samples*4;
        last_byte = 0;
        % Loop to read segy data
        tic
        for ii = 1:loop_end
            % Read blocktr x trace headers and trace data as uint32 into a temporary matrix
            tmptr = fread(seismic.fid,[120+2*seismic.n_samples,blocktr],'uint16=>uint16');
            tmptr = tmptr(1:120,:);
            [trace_header bytes_to_samples] = interpret(tmptr);
            
            trace_ilxl_bytes(:,1) = trace_header(bytes_to_samples == il_byte,:)';
            trace_ilxl_bytes(:,2) = trace_header(bytes_to_samples == xl_byte,:)';
            if ii == 1
                trace_ilxl_bytes(:,3) = last_byte+((skip_textual_binary+trc_head):trc_head+seismic.n_samples*4:blocktr*(trc_length+trc_head));
            else
                trace_ilxl_bytes(:,3) = repmat(last_byte,1,blocktr)+cumsum(repmat(trc_head,1,blocktr))+((1:1:blocktr).*trc_length);
            end
            last_byte = trace_ilxl_bytes(end,3);
            %....
            %     skip_textual_binary +...
            %     cumsum(repmat(trc_head,1,blocktr)) +...
            %     (1:1:blocktr-1).*trc_length;
            
            %                         fwrite(fid_write,reshape(trace_ilxl_bytes',[],1),'double');
            %fwrite(fopen(strcat(file_mat,'_lite'),'a'),[seismic.n_samples;reshape(trace_ilxl_bytes',[],1)],'double'); % saves _lite version
            fwrite(fid_write,reshape(trace_ilxl_bytes',[],1),'double'); % saves _lite version
            
            
            % fprintf('Block %d completed...\n',ii);
        end
        
        % Calculate the number of trace headers not read by the loop above
        leftovers = seismic.n_traces-loop_end*blocktr;
        
        
        % Read the remaining trace headers (if any)
        clearvars tmptrheader trace_header bytes_to_samples trace_ilxl_bytes
        if leftovers > 0
            tmptr = fread(seismic.fid,[120+2*seismic.n_samples,leftovers],'uint16=>uint16');
            tmptr = tmptr(1:120,:);
            [trace_header bytes_to_samples] = interpret(tmptr);
            % tmptrheader(1:120,1+loop_end*blocktr:seismic.n_traces) = tmptr(1:120,:);
            
            trace_ilxl_bytes(:,1) = trace_header(bytes_to_samples == il_byte,:)';
            trace_ilxl_bytes(:,2) = trace_header(bytes_to_samples == xl_byte,:)';
            trace_ilxl_bytes(:,3) = repmat(last_byte,1,leftovers)+cumsum(repmat(trc_head,1,leftovers))+((1:1:leftovers).*trc_length);
            
            %             % Scan scan to /mat file
            %
           fwrite(fid_write,reshape(trace_ilxl_bytes',[],1),'double');
           % fwrite(fopen(strcat(file_mat,'_lite'),'a'),reshape(trace_ilxl_bytes',[],1),'double'); % saves _lite version

            % fprintf('All %d blocks completed',ii+1);
        end
        fprintf('%d MB of data read (and written) at %d MB/sec in %d seconds\n',round((ll.bytes-3600)/(1024*1024)),round(((ll.bytes-3600)/(1024*1024))/toc),round(toc));
        toc
        
        % Write location of binary file into .mat file
        seismic.ilxl_bin_path = strcat(file_mat,'_lite');
        
        
        % Scan scan to /mat file
        fprintf('Saving seismic structure to file ...\n')
        save(file_mat,'-struct','seismic','-v7.3'); % Saves Seismic structure to mat file
        %fwrite(fid_write,reshape(trace_ilxl_bytes',[],1),'double');
        fprintf('Scan of file saved as %s\n',strcat(seismic.output_dir,'segy_structure/',file_mat));
        %                 fclose all;
        % Close segy file
        %fclose(seismic.fid);
        fclose('all');
        
        
    else
        % Scan of segy already exists so open it
        fprintf('\nScan of segy %s already exists\n',filename);
        fprintf('Opening .mat file %s\n',file_mat);
        cd(strcat(output_dir,'segy_structure/'));
        seismic = load(file_mat,'-mat');
    end
    clearvars tmptrheader trace_header bytes_to_samples trace_ilxl_bytes
end
end

function [trace_header bytes_to_samples] = interpret(tmptrheader)

byte_type = [ ...
    2*ones(7,1); ones(4,1);
    2*ones(8,1); ones(2,1);
    2*ones(4,1); ones(46,1);
    2*ones(5,1); ones(2,1);
    2*ones(1,1); ones(5,1);
    2*ones(1,1); ones(1,1);
    2*ones(1,1); ones(2,1);
    2*ones(1,1); 2*ones(1,1)];

ntr = size(tmptrheader,2);
trace_header = zeros(91,ntr);
bytes_to_samples = zeros(91,1);

count =1;
for ii = 1:91
    bytes_to_samples(ii,1) = 2*count-1;
    if byte_type(ii) == 1
        trace_header(ii,:) = double(tmptrheader(count,:));
        count = count+1;
    elseif byte_type(ii) == 2
        trace_header(ii,:) = double(tmptrheader(count,:))*2^16 + double(tmptrheader(count+1,:));
        count = count+2;
    end
end

trace_header(21,:) = trace_header(21,:)-2^16;

end

function ascii=ebcdic2ascii(ebcdic)
% Function converts EBCDIC string to ASCII
% see http://www.room42.com/store/computer_center/code_tables.shtml
%
% Written by: E. Rietsch: Feb. 20, 2000
% Last updated:
%
%           ascii=ebcdic2ascii(ebcdic)
% INPUT
% ebcdic    EBCDIC string
% OUTPUT
% ascii	   ASCII string

pointer= ...
    [ 0    16    32    46    32    38    45    46    46    46    46    46   123   125    92    48
    1    17    33    46    46    46    47    46    97   106   126    46    65    74    46    49
    2    18    34    50    46    46    46    46    98   107   115    46    66    75    83    50
    3    19    35    51    46    46    46    46    99   108   116    46    67    76    84    51
    4    20    36    52    46    46    46    46   100   109   117    46    68    77    85    52
    5    21    37    53    46    46    46    46   101   110   118    46    69    78    86    53
    6    22    38    54    46    46    46    46   102   111   119    46    70    79    87    54
    7    23    39    55    46    46    46    46   103   112   120    46    71    80    88    55
    8    24    40    56    46    46    46    46   104   113   121    46    72    81    89    56
    9    25    41    57    46    46    46    46   105   114   122    46    73    82    90    57
    10    26    42    58    46    33   124    58    46    46    46    46    46    46    46    46
    11    27    43    59    46    36    44    35    46    46    46    46    46    46    46    46
    12    28    44    60    60    42    37    64    46    46    46    46    46    46    46    46
    13    29    45    61    40    41    95    39    46    46    91    93    46    46    46    46
    14    30    46    46    43    59    62    61    46    46    46    46    46    46    46    46
    15    31    47    63   124    94    63    34    46    46    46    46    46    46    46    46];

pointer=reshape(pointer,1,256);

ascii=pointer(ebcdic+1);

end



%         % Extract inline - crossline information
%         seismic.ilxl_bytes = [il_byte xl_byte];
%         seismic.trace_ilxl_bytes(:,1) = seismic.trace_header(seismic.bytes_to_samples == il_byte,:)';
%         seismic.trace_ilxl_bytes(:,2) = seismic.trace_header(seismic.bytes_to_samples == xl_byte,:)';
%
%         coscaler = seismic.trace_header(21,1);
%         if coscaler < 0
%             coscaler = 1/abs(coscaler);
%         elseif coscaler == 0
%             coscaler = 1;
%         end
%
%         % extra bytes
%         seismic.extra_bytes_data = 0;
%         if (size(varargin,2) > 0)
%             seismic.extra_bytes = cell2mat(varargin);
%             seismic.extra_bytes_data = zeros(seismic.n_traces,length(seismic.extra_bytes));
%             for ii=1:1:length(seismic.extra_bytes)
%                seismic.extra_bytes_data(:,ii) = seismic.trace_header(seismic.bytes_to_samples == seismic.extra_bytes(ii),:)';
%                if or(and(seismic.extra_bytes(ii)>=73,seismic.extra_bytes(ii)<=85),and(seismic.extra_bytes(ii)>=181,seismic.extra_bytes(ii)<=185))
%                    seismic.extra_bytes_data(:,ii) = seismic.extra_bytes_data(:,ii)*coscaler;
%                end
%             end
%         end
%
%         % Create trace byte pointers
%         skip_textual_binary = 3600;
%         trc_head = 240;
%         trc_length = seismic.n_samples*4;
%         seismic.trace_ilxl_bytes(1:1:seismic.n_traces,3) = ....
%                  skip_textual_binary +...
%                  cumsum(repmat(trc_head,1,seismic.n_traces)) +...
%                  (0:1:seismic.n_traces-1).*trc_length;
%
%         c = clock;
%         seismic.file_id = c*c';
%
%         seismic.trc_head_length = trc_head;
%
%         % to be able to exclude traces outside of range
%         seismic.min_iline = min(seismic.trace_ilxl_bytes(:,1));
%         seismic.max_iline = max(seismic.trace_ilxl_bytes(:,1));
%         seismic.min_xline = min(seismic.trace_ilxl_bytes(:,2));
%         seismic.max_xline = max(seismic.trace_ilxl_bytes(:,2));
%
%         % find inline/crossline increments
%         seismic.n_iline = length(unique(seismic.trace_ilxl_bytes(:,1)));
%         seismic.n_xline = length(unique(seismic.trace_ilxl_bytes(:,2)));
%         seismic.il_inc = floor(mean(diff(unique(seismic.trace_ilxl_bytes(:,1)))));
%         seismic.xl_inc = floor(mean(diff(unique(seismic.trace_ilxl_bytes(:,2)))));
%
%         % calculate number of crosslines per inline
%         ils = unique(seismic.trace_ilxl_bytes(:,1));
%         loop = 1;
%         xl_per_il = zeros(length(ils),1);
%         for ii=1:seismic.n_traces
%             if ils(loop,1) == seismic.trace_ilxl_bytes(ii,1);
%                 xl_per_il(loop,1) = xl_per_il(loop,1)+1;
%             else
%                 loop=loop+1;
%                 xl_per_il(loop,1) = 1;
%             end
%         end
%
%         % calculate survey boundary inline/crossline/byte positions
%         last_xl_per_il = cumsum(xl_per_il);
%         first_xl_per_il = last_xl_per_il-xl_per_il+1;
%         for ii=1:length(ils)
%             seismic.boundary(ii,:) = [ils(ii,1),seismic.trace_ilxl_bytes(first_xl_per_il(ii),2:3),ils(ii,1),seismic.trace_ilxl_bytes(last_xl_per_il(ii),2:3)];
%         end
%         seismic.boundary = reshape(seismic.boundary',3,[])';
%
%         seismic.il_start_bytes = [seismic.boundary(logical(repmat([1;0],length(ils),1)),:),xl_per_il];